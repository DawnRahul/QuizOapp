
Main -> QuizOapp.java
	-->QuizExam.java - get questions and related data from database
			- storingQuestion() - get data from database
			- displayQuestions() - displays all the questions with options
			- startTest() - start quiz test, gives questions with option and choice to user to answer
		--->QuizQuestions.java - Class for Questions and related data 

Database connection -> DbConnect.java - Create connection to database
						- CreateDbConnection() - Returns Connection object
						

	

