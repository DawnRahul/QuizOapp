package com.dawnr.QuizOapp;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class QuizExam {
	
	//max. no. of questions is 10
	QuizQuestions[] quizQuestions = new QuizQuestions[10];
	int index = 0;
	int score = 0;
	int userAnswer;
	String correctAnswer;
	
	//Start Quiz
	public void QuizStart() throws SQLException {
		
		//gets all the questions and related data from data base : : method calling
		storingQuestion();
		
		//Display all questions n options
		//displayQuestions();
		
		//Start Quiz Test
		startQuiz();
		
	}
	
	//gets all the questions and related data from data base : method definition
	public void storingQuestion() throws SQLException {
		
		//Connecting to database - definition for connection is written in DbConnect.java 
		Connection con = DbConnect.CreateDbConnection();
		
		String q = "select * from questions;";
		
		Statement stmt = con.createStatement();
		
		ResultSet set = stmt.executeQuery(q);
		
		
		while(set.next()) {	
			int id = set.getInt(1);
			String question = set.getString(2);
			String[] options = new String[4]; //no. of options are 4
			//getting all 4 options in an Array
			for(int i=0; i<4; i++) {
				options[i] = set.getString(i+3);  //from 3rd column options column starts
			}
			String correctAnswer = set.getString(7);
			
			//creating objects of QuizQuestions
			quizQuestions[index] = new QuizQuestions(id, question, options, correctAnswer);
			index++;
		}
	}
	
//	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	public void displayQuestions() {
		System.out.println("++++++++++++++ QUIZ QUESTIONS ++++++++++++++++");
		
		if(quizQuestions.length != 0 ) {
			for(int i = 0; i<10 ; i++) {
				System.out.println("Q" + (i+1) + ". " + quizQuestions[i].getQuestion());
				//getOptions() return an array of options 
				String[] tempOptions = new String[quizQuestions[i].getOptions().length];
				tempOptions = quizQuestions[i].getOptions();
				for(int j = 0; j<4; j++) {
					System.out.println((j+1) + ". " + tempOptions[j]);
				}
				System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++");
				
			}
			
		}else {
			System.out.println("There are no questions in the question bank!!!");
		}
	}

	
//	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	public void startQuiz() {
		
		Scanner sc = new Scanner(System.in);
		
		if(quizQuestions.length != 0 ) {
			for(int i = 0; i<10 ; i++) {
				System.out.println("*********** QuizO App ************");
				
				System.out.println("Q" + (i+1) + ". " + quizQuestions[i].getQuestion());
				//getOptions() return an array of options 
				String[] tempOptions = new String[quizQuestions[i].getOptions().length];
				tempOptions = quizQuestions[i].getOptions();
				for(int j = 0; j<4; j++) {
					System.out.println((j+1) + ". " + tempOptions[j]);
				}
				
				System.out.println("___________________________________________________");
				System.out.print("Enter the your option: ");
				userAnswer = sc.nextInt();
				
				//if entered option not in range
				while(userAnswer <1 || userAnswer > 4) {
					System.out.println("Entered option is not present!!!");
					System.out.print("Enter your option (1 to 4): ");
					userAnswer = sc.nextInt();
				}
				correctAnswer = quizQuestions[i].getCorrectAnswer();
				//checking user's answer is correct or not
				if(tempOptions[userAnswer - 1].equalsIgnoreCase(correctAnswer)) {
					score++;
				}else {
					//Here in future we can track incorrect answered questions by storing indexes in a new array
				}
				
				System.out.print("\n\n");
				//Clearing console for new Question (Do not work on Eclipse)
				System.out.print("\033[H\033[2J");  
		        System.out.flush();
				
			}//for-loop
			
			System.out.println("*************** SCORE BOARD ******************");
			if(score > 5) {
				System.out.println("PASSED");
				System.out.println("\nScore : " + score + "/ 10");
			}else {
				System.out.println("FAILED");
				System.out.println("\nScore : " + score + "/ 10");
			}
			
			System.out.println("*************** ALL THE BEST ******************");
			
			
		}else {
			System.out.println("There are no questions in the question bank!!!");
		}
		
		
		
	}
	
	
	
}
