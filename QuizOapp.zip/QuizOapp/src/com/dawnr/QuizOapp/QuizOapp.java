package com.dawnr.QuizOapp;

import java.sql.*;


public class QuizOapp {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		QuizExam quizExam = new QuizExam();
		
		quizExam.QuizStart();
	}

}
